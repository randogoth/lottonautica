# SPDX-FileCopyrightText: 2025-present randogoth <kflux@posteo.de>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
