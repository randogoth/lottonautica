import json
from statistics import mean, stdev

class Lyagushka:
    def __init__(self, dataset):
        self.dataset = sorted(dataset)
        self.anomalies = []

    def _create_anomaly(self, elements, start, end):
        span_length = end - start
        return {
            "elements": elements,
            "start": start,
            "end": end,
            "span_length": span_length,
            "num_elements": len(elements),
            "centroid": start + span_length / 2.0,
            "z_score": None
        }

    def _calculate_mean_distance(self):
        return mean(self.dataset[i + 1] - self.dataset[i] for i in range(len(self.dataset) - 1))

    def scan_anomalies(self, factor, min_cluster_size):
        mean_distance = self._calculate_mean_distance()
        cluster_threshold = mean_distance / factor
        gap_threshold = factor * mean_distance

        current_cluster = []
        for i in range(len(self.dataset) - 1):
            gap_size = self.dataset[i + 1] - self.dataset[i]

            if gap_size <= cluster_threshold:
                if not current_cluster:
                    current_cluster.extend([self.dataset[i], self.dataset[i + 1]])
                else:
                    current_cluster.append(self.dataset[i + 1])
            else:
                if len(current_cluster) >= min_cluster_size:
                    self._add_anomaly(current_cluster)
                current_cluster = []

                if gap_size > gap_threshold:
                    self._add_anomaly([], self.dataset[i], self.dataset[i + 1])

        if len(current_cluster) >= min_cluster_size:
            self._add_anomaly(current_cluster)

    def _add_anomaly(self, elements, start=None, end=None):
        if elements:
            self.anomalies.append(self._create_anomaly(elements, elements[0], elements[-1]))
        else:
            self.anomalies.append(self._create_anomaly(elements, start, end))

    def search(self, factor, min_cluster_size):
        self.scan_anomalies(factor, min_cluster_size)

        cluster_densities = [
            a["num_elements"] / a["span_length"] 
            for a in self.anomalies if a["num_elements"] > 0 and a["span_length"] > 0
        ]
        mean_density = mean(cluster_densities) if cluster_densities else 0.0
        std_dev_density = stdev(cluster_densities) if len(cluster_densities) > 1 else 0.0

        span_lengths = [a["span_length"] for a in self.anomalies]
        mean_span_length = mean(span_lengths)
        std_dev_span_length = stdev(span_lengths) if len(span_lengths) > 1 else 0.0

        for a in self.anomalies:
            a["z_score"] = self._calculate_z_score(a, mean_density, std_dev_density, mean_span_length, std_dev_span_length)

        return json.dumps(self.anomalies, indent=4)

    def _calculate_z_score(self, anomaly, mean_density, std_dev_density, mean_span_length, std_dev_span_length):
        if anomaly["num_elements"] > 0 and std_dev_density:
            return (anomaly["num_elements"] / anomaly["span_length"] - mean_density) / std_dev_density
        elif std_dev_span_length:
            return (anomaly["span_length"] - mean_span_length) / std_dev_span_length
        return 0.0
