from .lyagushka import *

__doc__ = lyagushka.__doc__
if hasattr(lyagushka, "__all__"):
    __all__ = lyagushka.__all__